#import "ABKInAppMessageViewController.h"

@class ABKLabel;

/*
 * Appboy Public API: ABKInAppMessageSlideupViewController
 */
NS_ASSUME_NONNULL_BEGIN
@interface ABKInAppMessageSlideupViewController : ABKInAppMessageViewController

@property (nullable) IBOutlet UIImageView *arrowImage;

@end
NS_ASSUME_NONNULL_END
