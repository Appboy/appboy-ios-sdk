#import <Foundation/Foundation.h>
#import "ABKInAppMessageHTML.h"

/*
 * Appboy Public API: ABKInAppMessageHTMLFull
 */
NS_ASSUME_NONNULL_BEGIN
@interface ABKInAppMessageHTMLFull : ABKInAppMessageHTML
@end
NS_ASSUME_NONNULL_END
