#import "ABKInAppMessageImmersiveViewController.h"

/*
 * Appboy Public API: ABKInAppMessageModalViewController
 */
NS_ASSUME_NONNULL_BEGIN
@interface ABKInAppMessageModalViewController : ABKInAppMessageImmersiveViewController
@end
NS_ASSUME_NONNULL_END
